homeApp.controller('RegistrationController',['$scope',function($scope)
{

    $scope.userInfo={
        email:"",
        username:"",
        password:"",
        dob:""
    }

     $scope.register=function()
     {
         console.log($scope.userInfo);
     }



}])