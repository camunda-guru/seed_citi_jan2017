homeApp.controller('HomeController',['$scope',function($scope)
{

    $scope.menuItems={
        "home":"Home",
        "product":"Product",
        "services":"Services"
    }
}]);