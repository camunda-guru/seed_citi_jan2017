import {Component, OnInit} from "@angular/core";
import {MenuService} from "../services/services.menuservice";

@Component({
    selector:'menu-list',
    templateUrl:'./menu/menu.component.html',
    styleUrls:['./menu/menu.component.css']

})
export class MenuComponent implements OnInit {

    private localMenuData:any=[];

    constructor(private menuData: MenuService) {

    }

    ngOnInit() {
        this.menuData.getMenuData().then(response => {

            response.forEach((obj) => {
                this.localMenuData.push(obj);
            })

        });

    }

}