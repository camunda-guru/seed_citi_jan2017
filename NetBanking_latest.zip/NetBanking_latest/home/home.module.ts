import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {HomeComponent} from "./home.component";
import {MenuComponent} from "../menu/menu.component";
import {MenuService} from "../services/services.menuservice";


@NgModule({
    imports:[BrowserModule,CommonModule],
    declarations:[HomeComponent,MenuComponent],
    providers:[MenuService],
    bootstrap:[HomeComponent]
})
export class HomeModule
{

}