export class Menu{
    private menuId:number;
    private menuName:string;
    constructor(id:number,name:string)
    {
        this.menuId=id;
        this.menuName=name;
    }

    get MenuId():number
    {
        return this.menuId;
    }

    get MenuName():string
    {
        return this.menuName;
    }

}