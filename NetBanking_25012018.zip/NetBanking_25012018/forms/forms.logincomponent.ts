import {Component} from "@angular/core";

@Component({
    templateUrl:'../forms/forms.logincomponent.html',
    styleUrls:['../forms/forms.logincomponent.css']
})
export  class LoginComponent
{

}