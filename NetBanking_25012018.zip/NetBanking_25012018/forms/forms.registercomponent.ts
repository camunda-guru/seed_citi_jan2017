import {Component} from "@angular/core";
import {FormControl, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Customer} from "../models/customerModel";
import {Router} from "@angular/router";
import {UserService} from "../services/userService";


@Component({
    templateUrl:'../forms/forms.registercomponent.html',
    styleUrls:['../forms/forms.registercomponent.css']
})
export  class RegisterComponent
{
   private customer:Customer;
   private registerForm:FormGroup;
   private firstName:FormControl;
   private lastName:FormControl;
   private dob:FormControl;
   private email:FormControl;
   private password:FormControl;
   private confirmPassword:FormControl;
    errorMessage: String;
   constructor(private formBuilder:FormBuilder,private router:Router,private userService:UserService)
   {

       this.firstName=new FormControl('',[Validators.minLength(5),
         Validators.maxLength(25),Validators.required, Validators.pattern('[A-Za-z]{5,25}')]);

       this.lastName=new FormControl('',[Validators.minLength(5),
           Validators.maxLength(25),Validators.required,Validators.pattern('[A-Za-z]{5,25}')]);
       this.dob=new FormControl('',[Validators.required]);
       this.email=new FormControl('',[Validators.required]);
       this.password=new FormControl('',[Validators.required]);

       this.confirmPassword=new FormControl('',[Validators.required ]);


       this.registerForm=formBuilder.group({
           firstName:this.firstName,
           lastName:this.lastName,
           dob:this.dob,
           email:this.email,
          password:this.password,
          confirmPassword:this.confirmPassword,

       })
   }

   save():void
   {
      console.log(this.registerForm.value);
      this.customer=this.registerForm.value;
       this.userService.addUserWithPromise(this.customer)
           .then( res => {
                   console.log(res);
               },
               error => this.errorMessage = <any>error);

       this.router.navigate(["/Login"]);
   }




}