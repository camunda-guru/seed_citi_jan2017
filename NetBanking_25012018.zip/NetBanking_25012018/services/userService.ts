import {Injectable} from "@angular/core";

import 'rxjs';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

import {Customer} from "../models/customerModel";

@Injectable()
export class UserService
{
    url = "http://localhost:3000/register";

    constructor(private http:Http)
    {

    }

    getUserInfo()
    {

        return this.http.get("https://restcountries.eu/rest/v2/all").flatMap((data)=>data.json())


    }


    getOpecData()
    {
        return this.http.get('https://www.quandl.com/api/v3/datasets/OPEC/ORB.json').flatMap((data)=>data.json());
    }

    addUserWithPromise(customer:Customer): Promise<Customer> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, customer, options).toPromise()
            .then(this.extractData);
           // .catch(this.handleErrorPromise);
    }
    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }
    private handleErrorObservable (error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }
    private handleErrorPromise (error: Response | any) {
        console.log(error.message || error);
        return Promise.reject(error.message || error);
    }
}