import {Injectable} from "@angular/core";
import {OPEC} from "../models/opecModel";
import {OPECDATA} from "../models/opecData";

@Injectable()
export class OPECService
{

    getOPECData():Promise<OPEC[]>
    {
       return Promise.resolve(OPECDATA);
    }


}