import {Injectable} from "@angular/core";
import {Menu} from "../models/models.menu";
import {MENUDATA} from "../models/models.menudata";

@Injectable()
export class MenuService
{

    getMenuData():Promise<Menu[]>
    {
      return Promise.resolve( MENUDATA);
    }

}