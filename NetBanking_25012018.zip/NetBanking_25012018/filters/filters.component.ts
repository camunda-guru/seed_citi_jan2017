import {Pipe, PipeTransform} from "@angular/core";


@Pipe({name:'NameFilter'})
export class CountryNamePipe implements PipeTransform
{
    transform(value: any, letter:string): any
    {
        return value.filter(obj => obj.name.startsWith(letter));

    }
}