import {Menu} from './models.menu'

export const MENUDATA:Menu[]=[new Menu(1,"Home"),
    new Menu(2,"Management"),
    new Menu(3,"Product"),
    new Menu(4,"Feedback"),
    new Menu(5,"About us"),  new Menu(6,"Register"),
    new Menu(7,"Login")];