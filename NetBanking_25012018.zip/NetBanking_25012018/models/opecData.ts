import {OPEC} from "./opecModel";

export const OPECDATA:OPEC[]=[ new OPEC("13/12/2017",60.5),
    new OPEC("12/12/2017",61.5),
    new OPEC("11/12/2017",63.5),

    new OPEC("10/12/2017",58.5),
    new OPEC("09/12/2017",61.98),
    new OPEC("08/12/2017",59.5)


]