import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {HomeComponent} from "./home.component";
import {MenuComponent} from "../menu/menu.component";
import {MenuService} from "../services/services.menuservice";
import {HttpModule} from "@angular/http";
import {UserService} from "../services/userService";
import { AppRoutingModule }  from './home-routing.module';

import {CountryComponent} from "../country/country.component";
import {FinanceComponent} from "../finance/finance.component";
import {OPECService} from "../services/mock-service";
import {HightLightComponent} from "../directives/directive.component";
import {CountryNamePipe} from "../filters/filters.component";
import {RegisterComponent} from "../forms/forms.registercomponent";
import {LoginComponent} from "../forms/forms.logincomponent";
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {EqualValidator}  from '../forms/matchvalidator'

@NgModule({
    imports:[BrowserModule,CommonModule,HttpModule,AppRoutingModule,ReactiveFormsModule,
        FormsModule],
    declarations:[HomeComponent,MenuComponent,HightLightComponent,
        CountryNamePipe, CountryComponent,FinanceComponent,
        RegisterComponent,LoginComponent,EqualValidator],
    providers:[MenuService,UserService,OPECService],
    bootstrap:[HomeComponent]
})
export class HomeModule
{

}