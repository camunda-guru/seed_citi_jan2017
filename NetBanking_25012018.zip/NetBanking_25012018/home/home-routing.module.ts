import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {CountryComponent} from "../country/country.component";
import {FinanceComponent} from "../finance/finance.component";
import {RegisterComponent} from "../forms/forms.registercomponent";
import {LoginComponent} from "../forms/forms.logincomponent";

const routes: Routes = [
    {
        path: 'About us',
        component: CountryComponent,
        outlet: 'aboutusOutlet'
    },
    {
        path: 'Product',
        component: FinanceComponent,
        outlet: 'finOutlet'
    }
    ,
    {
        path: 'Register',
        component: RegisterComponent

    }
    ,
    {
        path: 'Login',
        component: LoginComponent

    }
];
@NgModule({
  imports: [ 
          RouterModule.forRoot(routes) 
  ],
  exports: [ 
          RouterModule 
  ]
})
export class AppRoutingModule{ } 