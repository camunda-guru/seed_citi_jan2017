import {Component, OnInit} from "@angular/core";
import {OPECService} from "../services/mock-service";

@Component({
    templateUrl:'../finance/finance.component.html',
    styleUrls:['../finance/finance.component.css']
})
export class FinanceComponent implements OnInit
{
    private finData:any=[];

    constructor(private opecService:OPECService)
    {

    }
    ngOnInit()
    {
          this.opecService.getOPECData().then(response=>{

             response.forEach((obj)=>{
                 this.finData.push(obj);
             })


              console.log(this.finData);
          })


    }

}