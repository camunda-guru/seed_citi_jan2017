"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var oopsdemo_1 = require("./oopsdemo");
var Logger = oopsdemo_1.Ecommerce.Logger;
var SeasonalProduct = /** @class */ (function (_super) {
    __extends(SeasonalProduct, _super);
    function SeasonalProduct(id, name, date, value, offerValue) {
        var _this = _super.call(this, id, name, date, value) || this;
        _this.offer = offerValue;
        return _this;
    }
    return SeasonalProduct;
}(oopsdemo_1.Ecommerce.Product));
var seasonalProduct = new SeasonalProduct(1, "Note 4", "2016/4/4", 43943, 0.5);
console.log(seasonalProduct.ProductId);
var FileLogger = /** @class */ (function (_super) {
    __extends(FileLogger, _super);
    function FileLogger() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FileLogger.prototype.writeToFile = function () {
        //implement code
    };
    return FileLogger;
}(Logger));
var logger = new FileLogger();
console.log(oopsdemo_1.Ecommerce.Logger.getRules());
