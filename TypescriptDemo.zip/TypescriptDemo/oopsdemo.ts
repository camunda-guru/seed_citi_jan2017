export module Ecommerce {

    export class Product {
        private productId: number;
        private productName: string;
        private dop: string;
        private cost: number;

        constructor(id: number, name: string, date: string, value: number) {
            this.productId = id;
            this.productName = name;
            this.dop = date;
            this.cost = value;
        }

        //properties
        get ProductId(): number {
            return this.productId;
        }

        set ProductId(value: number) {
            this.productId = value;
        }
    }

    export abstract class Logger
    {
        static rule:string;
        abstract writeToFile():void;
        static getRules():string
        {
            Logger.rule="Es@016";
            return Logger.rule+"static rules for all subclassess";
        }

    }

}


export module Sales
{
    export class Product {
        private productId: number;
        private productName: string;
        private salesDate: string;
        private salesAmount: number;

        constructor(id: number, name: string, date: string, value: number) {
            this.productId = id;
            this.productName = name;
            this.salesDate = date;
            this.salesAmount = value;
        }

        //properties
        get ProductId(): number {
            return this.productId;
        }

        set ProductId(value: number) {
            this.productId = value;
        }
    }
}




/*
var product=new Product(4365734,"Mobile","2017/2/2",589369);
console.log(product.ProductId);
//change the cost
product.ProductId=67876487;
console.log(product.ProductId);
*/