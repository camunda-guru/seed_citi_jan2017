var firstLake = {
    name: 'Caspian Sea',
    length: 1199,
    depth: 1025,
    area: 371000,
    isFreshwater: false,
    countries: ['Kazakhstan', 'Russia', 'Turkmenistan', 'Azerbaijan', 'Iran']
};
console.log(firstLake.countries);
var secondLake = {
    name: 'Superior',
    depth: 406.3,
    length: 616,
    area: 82100,
    isFreshwater: true,
    countries: ['Canada', 'United States']
};
var thirdLake = {
    name: 'Baikal',
    depth: 1637,
    length: 636,
    area: 31500,
    isFreshwater: true,
    countries: ['Russia'],
    frozen: ['January', 'February', 'March', 'April', 'May']
};
var distobj = { fromDistance: 56, toDistance: 130 };
//annonymous instance
var tank = {
    size: 50,
    health: 100,
    range: distobj,
    damage: 12
};
console.log('Tank details...', '-->', tank);
// This is Okay
tank.health = 95;
console.log('After modifying Tank details...', '-->', tank);
var tankHit = function (tankName, damageDone) {
    tankName.health -= damageDone;
    return tankName.health;
};
console.log(tankHit(tank, 2));
var Test = /** @class */ (function () {
    function Test() {
    }
    return Test;
}());
