var emp_firstName:string;
var emp_location:string;
var emp_email:string;
var age:number;

age=38;
emp_firstName="Arun";
emp_location="Chennai";
emp_email="arun@sample.com"
console.log(emp_firstName,'-->',emp_location,'-->',emp_email,'-->',age);

enum job_type{
    PERMANANENT,
    FREELANCER
}

var emp_jobtype=job_type.PERMANANENT;
console.log(emp_jobtype);
//homogeneous data type

var friend_List:string[]=["Jaya","Shiva","Sapna","Aruna"];

friend_List.forEach(obj=>{
    console.log(obj);
})
//heterogeneous data types
var customerInfo:any=["Jaya",28548,true,
    {skill:["java","c#","ang2"]}
]
customerInfo.forEach(obj=>{

    if(typeof (obj)=="object")
        //console.log(obj.skill);
    {
        obj.skill.forEach(elem=>{
            console.log(elem);
        })


    }

})



function testDataType(data:number):void
{
   console.log(typeof (data));
}

testDataType(573675);

//default values

function readUserInfo(name:string,country:string="India"):string
{
   return ("Name="+name+"residing in="+country);

}

console.log(readUserInfo("Anoop","USA"));

//optional parameters
function displaySkills(name,...skillSet)
{
  console.log(name,'-->',skillSet);
}

displaySkills("Anu","Python","C++");
displaySkills("Anu","Python","C++","Java");
displaySkills("Anu");

