var emp_firstName;
var emp_location;
var emp_email;
var age;
age = 38;
emp_firstName = "Arun";
emp_location = "Chennai";
emp_email = "arun@sample.com";
console.log(emp_firstName, '-->', emp_location, '-->', emp_email, '-->', age);
var job_type;
(function (job_type) {
    job_type[job_type["PERMANANENT"] = 0] = "PERMANANENT";
    job_type[job_type["FREELANCER"] = 1] = "FREELANCER";
})(job_type || (job_type = {}));
var emp_jobtype = job_type.PERMANANENT;
console.log(emp_jobtype);
//homogeneous data type
var friend_List = ["Jaya", "Shiva", "Sapna", "Aruna"];
friend_List.forEach(function (obj) {
    console.log(obj);
});
//heterogeneous data types
var customerInfo = ["Jaya", 28548, true,
    { skill: ["java", "c#", "ang2"] }
];
customerInfo.forEach(function (obj) {
    if (typeof (obj) == "object") 
    //console.log(obj.skill);
    {
        obj.skill.forEach(function (elem) {
            console.log(elem);
        });
    }
});
function testDataType(data) {
    console.log(typeof (data));
}
testDataType(573675);
//default values
function readUserInfo(name, country) {
    if (country === void 0) { country = "India"; }
    return ("Name=" + name + "residing in=" + country);
}
console.log(readUserInfo("Anoop", "USA"));
//optional parameters
function displaySkills(name) {
    var skillSet = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        skillSet[_i - 1] = arguments[_i];
    }
    console.log(name, '-->', skillSet);
}
displaySkills("Anu", "Python", "C++");
displaySkills("Anu", "Python", "C++", "Java");
displaySkills("Anu");
