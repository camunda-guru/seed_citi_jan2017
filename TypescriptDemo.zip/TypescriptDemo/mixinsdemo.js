// Disposable Mixin
var Voice = /** @class */ (function () {
    function Voice() {
    }
    Voice.prototype.talk = function () {
        return "invoke caller";
    };
    return Voice;
}());
// Activatable Mixin
var SMS = /** @class */ (function () {
    function SMS() {
    }
    SMS.prototype.text = function () {
        return "send Text";
    };
    return SMS;
}());
var Phone = /** @class */ (function () {
    function Phone() {
    }
    Phone.prototype.talk = function () {
        return "Phone voice";
    };
    Phone.prototype.text = function () {
        return "Phone sms";
    };
    return Phone;
}());
applyMixins(Phone, [Voice, SMS]);
var phone = new Phone();
console.log(phone.talk());
function applyMixins(derivedCtor, baseCtors) {
    baseCtors.forEach(function (baseCtor) {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
            derivedCtor.prototype[name] = baseCtor.prototype[name];
        });
    });
}
