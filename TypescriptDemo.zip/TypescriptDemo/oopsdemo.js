"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Ecommerce;
(function (Ecommerce) {
    var Product = /** @class */ (function () {
        function Product(id, name, date, value) {
            this.productId = id;
            this.productName = name;
            this.dop = date;
            this.cost = value;
        }
        Object.defineProperty(Product.prototype, "ProductId", {
            //properties
            get: function () {
                return this.productId;
            },
            set: function (value) {
                this.productId = value;
            },
            enumerable: true,
            configurable: true
        });
        return Product;
    }());
    Ecommerce.Product = Product;
    var Logger = /** @class */ (function () {
        function Logger() {
        }
        Logger.getRules = function () {
            Logger.rule = "Es@016";
            return Logger.rule + "static rules for all subclassess";
        };
        return Logger;
    }());
    Ecommerce.Logger = Logger;
})(Ecommerce = exports.Ecommerce || (exports.Ecommerce = {}));
var Sales;
(function (Sales) {
    var Product = /** @class */ (function () {
        function Product(id, name, date, value) {
            this.productId = id;
            this.productName = name;
            this.salesDate = date;
            this.salesAmount = value;
        }
        Object.defineProperty(Product.prototype, "ProductId", {
            //properties
            get: function () {
                return this.productId;
            },
            set: function (value) {
                this.productId = value;
            },
            enumerable: true,
            configurable: true
        });
        return Product;
    }());
    Sales.Product = Product;
})(Sales = exports.Sales || (exports.Sales = {}));
/*
var product=new Product(4365734,"Mobile","2017/2/2",589369);
console.log(product.ProductId);
//change the cost
product.ProductId=67876487;
console.log(product.ProductId);
*/ 
