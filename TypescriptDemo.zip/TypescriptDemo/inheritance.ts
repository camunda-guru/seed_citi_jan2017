import {Ecommerce,Sales} from './oopsdemo';
import Logger = Ecommerce.Logger;

class SeasonalProduct extends Ecommerce.Product
{
    private offer:number;
    constructor(id:number, name:string, date:string,value:number,offerValue:number)
    {
        super(id,name,date,value);
        this.offer=offerValue;
    }

}

var seasonalProduct=new SeasonalProduct(1,"Note 4","2016/4/4",43943, 0.5);
console.log(seasonalProduct.ProductId);

class FileLogger extends Logger
{

    writeToFile():void
    {
         //implement code
    }

}

var logger=new FileLogger();

console.log(Ecommerce.Logger.getRules());